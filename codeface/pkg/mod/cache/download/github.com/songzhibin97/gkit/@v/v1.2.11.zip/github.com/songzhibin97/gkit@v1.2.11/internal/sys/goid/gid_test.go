package goid

import "testing"

func TestGetGID(t *testing.T) {
	t.Log(GetGID())
}
