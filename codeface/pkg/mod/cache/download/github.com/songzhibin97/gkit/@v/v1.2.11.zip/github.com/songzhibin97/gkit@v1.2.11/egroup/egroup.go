package egroup

// package egroup: 控制组件生命周期
