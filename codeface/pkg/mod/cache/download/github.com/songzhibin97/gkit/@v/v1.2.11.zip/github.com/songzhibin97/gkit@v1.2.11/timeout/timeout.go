package timeout

// package timeout: 管理组件间传递超时控制
