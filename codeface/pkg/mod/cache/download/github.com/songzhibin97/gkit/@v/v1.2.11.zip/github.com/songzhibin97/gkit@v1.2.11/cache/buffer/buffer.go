package buffer

// package buffer:
// Byte 复用
