package bbr

import "errors"

var LimitExceed = errors.New("509:过载保护")
