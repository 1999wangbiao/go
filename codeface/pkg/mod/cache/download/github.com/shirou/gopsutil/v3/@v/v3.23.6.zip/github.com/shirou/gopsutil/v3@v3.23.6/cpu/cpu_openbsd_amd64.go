package cpu

type cpuTimes struct {
	User uint64
	Nice uint64
	Sys  uint64
	Spin uint64
	Intr uint64
	Idle uint64
}
