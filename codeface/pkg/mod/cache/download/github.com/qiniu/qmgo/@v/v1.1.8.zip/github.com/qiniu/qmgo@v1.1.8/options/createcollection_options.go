package options

import "go.mongodb.org/mongo-driver/mongo/options"

type CreateCollectionOptions struct {
	*options.CreateCollectionOptions
}