package options

import "go.mongodb.org/mongo-driver/mongo/options"

type AggregateOptions struct {
	*options.AggregateOptions
}
