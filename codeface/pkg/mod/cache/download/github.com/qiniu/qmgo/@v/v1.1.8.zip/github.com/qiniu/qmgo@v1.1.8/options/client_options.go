package options

import "go.mongodb.org/mongo-driver/mongo/options"

type ClientOptions struct {
	*options.ClientOptions
}
