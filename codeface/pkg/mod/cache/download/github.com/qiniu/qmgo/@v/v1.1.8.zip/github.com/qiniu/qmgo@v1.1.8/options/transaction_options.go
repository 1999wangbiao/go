package options

import "go.mongodb.org/mongo-driver/mongo/options"

type TransactionOptions struct {
	*options.TransactionOptions
}
